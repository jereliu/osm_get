package org.osm2world.core.math;

public interface Vector3D {
	public double getX();
	public double getY();
	public double getZ();
}
